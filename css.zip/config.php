<?php

//SITE GLOBAL CONFIGURATION
$email = "yourmail@here.com";   //<-- Your email

?>
